package com.printxpress.print

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.printxpress.print.adapters.ProductAdapter
import com.printxpress.print.models.Product

class ProductsActivity : AppCompatActivity() {

    private lateinit var adapter: ProductAdapter
    private val allProducts = listOf(
        Product("1", "Business Cards", "Stationery", "Premium 350gsm matte/glossy cards. Pack of 100.", 850.0),
        Product("2", "A4 Flyers", "Marketing", "Full color single-sided prints on 120gsm paper. Pack of 50.", 1250.0),
        Product("3", "Vinyl Banners", "Large Format", "Durable outdoor vinyl with eyelets. Standard 3x2 ft size.", 2400.0),
        Product("4", "Promotional Posters", "Marketing", "High-quality A3 size prints on 200gsm photo paper.", 450.0),
        Product("5", "Die-cut Stickers", "Stickers", "Waterproof custom shaped stickers. Sheet of 20.", 650.0),
        Product("6", "Ceramic Mugs", "Merchandise", "11oz white ceramic mug with wraparound custom print.", 950.0),
        Product("7", "Cotton T-shirts", "Merchandise", "100% cotton shirts with high-durability DTF print.", 1850.0)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)

        findViewById<View>(R.id.backButton).setOnClickListener {
            finish()
        }

        val recyclerView = findViewById<RecyclerView>(R.id.productRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = ProductAdapter(allProducts) { product ->
            val intent = Intent(this, ProductDetailActivity::class.java).apply {
                putExtra("PRODUCT_NAME", product.name)
                putExtra("PRODUCT_DESC", product.description)
                putExtra("PRODUCT_CAT", product.category)
                putExtra("PRODUCT_PRICE", product.basePrice)
            }
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        val searchEditText = findViewById<TextInputEditText>(R.id.searchEditText)
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterProducts(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterProducts(query: String) {
        val filteredList = allProducts.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.category.contains(query, ignoreCase = true)
        }
        adapter.updateList(filteredList)
    }
}
