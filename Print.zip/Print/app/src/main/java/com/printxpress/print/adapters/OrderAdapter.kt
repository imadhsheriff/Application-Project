package com.printxpress.print.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.printxpress.print.R
import com.printxpress.print.models.Order

class OrderAdapter(private val orders: List<Order>) :
    RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val idText: TextView = view.findViewById(R.id.orderIdText)
        val statusText: TextView = view.findViewById(R.id.orderStatusText)
        val nameText: TextView = view.findViewById(R.id.orderProductName)
        val dateText: TextView = view.findViewById(R.id.orderDateText)
        val priceText: TextView = view.findViewById(R.id.orderPriceText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]
        holder.idText.text = "ORDER #${order.orderId}"
        holder.nameText.text = order.productName
        holder.dateText.text = "Placed on ${order.date}"
        holder.priceText.text = "LKR ${String.format("%.2f", order.price)}"
        holder.statusText.text = order.status.uppercase()

        when (order.status.lowercase()) {
            "confirmed" -> holder.statusText.setBackgroundResource(R.drawable.status_bg_confirmed)
            "cancelled" -> holder.statusText.setBackgroundResource(R.drawable.status_bg_cancelled)
            else -> holder.statusText.setBackgroundResource(R.drawable.status_bg_pending)
        }
    }

    override fun getItemCount() = orders.size
}
