package com.printxpress.print

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProductDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        findViewById<View>(R.id.backButton).setOnClickListener {
            finish()
        }

        val productName = intent.getStringExtra("PRODUCT_NAME") ?: "Product"
        val productDesc = intent.getStringExtra("PRODUCT_DESC") ?: ""
        val productCat = intent.getStringExtra("PRODUCT_CAT") ?: ""
        val productPrice = intent.getDoubleExtra("PRODUCT_PRICE", 0.0)

        findViewById<TextView>(R.id.detailProductName).text = productName
        findViewById<TextView>(R.id.detailProductDescription).text = productDesc
        findViewById<TextView>(R.id.detailProductCategory).text = productCat
        findViewById<TextView>(R.id.detailProductPrice).text = "Rs. ${String.format("%.2f", productPrice)}"

        setupDropdowns(productName)

        findViewById<Button>(R.id.addToCartButton).setOnClickListener {
            val intent = Intent(this, CheckoutActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupDropdowns(productName: String) {
        val paperTypes: Array<String>
        val sizes: Array<String>
        val typeLabel: String

        when {
            productName.contains("Cards", ignoreCase = true) -> {
                typeLabel = "Paper Type"
                paperTypes = arrayOf("350gsm Matte", "350gsm Glossy", "Linen Texture", "Recycled Card")
                sizes = arrayOf("Standard (3.5 x 2 in)", "Square (2.5 x 2.5 in)", "Mini (3 x 1 in)")
            }
            productName.contains("Flyers", ignoreCase = true) || productName.contains("Posters", ignoreCase = true) -> {
                typeLabel = "Paper Type"
                paperTypes = arrayOf("120gsm Bond", "150gsm Glossy", "200gsm Silk", "250gsm Premium")
                sizes = arrayOf("A5 Size", "A4 Size", "A3 Size", "DL Size")
            }
            productName.contains("Banners", ignoreCase = true) -> {
                typeLabel = "Material"
                paperTypes = arrayOf("Standard Vinyl", "Mesh Vinyl", "Blockout Vinyl", "Fabric")
                sizes = arrayOf("3 x 2 ft", "4 x 3 ft", "6 x 3 ft", "Custom Size")
            }
            productName.contains("Stickers", ignoreCase = true) -> {
                typeLabel = "Finish"
                paperTypes = arrayOf("Waterproof Vinyl", "Paper Sticker", "Clear Vinyl", "Holographic")
                sizes = arrayOf("Small (1x1 in)", "Medium (2x2 in)", "Large (4x4 in)")
            }
            productName.contains("Mugs", ignoreCase = true) -> {
                typeLabel = "Mug Type"
                paperTypes = arrayOf("Standard Ceramic", "Magic Heat Change", "Frosted Glass", "Inner Color")
                sizes = arrayOf("11oz Standard", "15oz Jumbo", "Travel Mug")
            }
            productName.contains("T-shirts", ignoreCase = true) -> {
                typeLabel = "Fabric"
                paperTypes = arrayOf("100% Cotton", "Polyester Blend", "Premium Organic", "Dry Fit")
                sizes = arrayOf("Small (S)", "Medium (M)", "Large (L)", "Extra Large (XL)", "XXL")
            }
            else -> {
                typeLabel = "Material"
                paperTypes = arrayOf("Standard Material", "Premium Material")
                sizes = arrayOf("Standard Size", "Custom Size")
            }
        }

        findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.paperTypeInputLayout).hint = typeLabel

        val paperAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, paperTypes)
        findViewById<AutoCompleteTextView>(R.id.paperTypeDropdown).setAdapter(paperAdapter)

        val sizeAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, sizes)
        findViewById<AutoCompleteTextView>(R.id.sizeDropdown).setAdapter(sizeAdapter)
    }
}
