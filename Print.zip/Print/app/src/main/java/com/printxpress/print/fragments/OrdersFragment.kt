package com.printxpress.print.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.printxpress.print.R
import com.printxpress.print.adapters.OrderAdapter
import com.printxpress.print.models.Order

class OrdersFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_orders, container, false)

        val recyclerView = view.findViewById<RecyclerView>(R.id.ordersRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        val sampleOrders = listOf(
            Order("54321", "Business Cards (Premium)", "10 July 2026", 1500.0, "Confirmed"),
            Order("54320", "Ceramic Mug", "08 July 2026", 950.0, "Cancelled"),
            Order("54319", "A4 Flyers", "05 July 2026", 1250.0, "Confirmed")
        )

        recyclerView.adapter = OrderAdapter(sampleOrders)

        return view
    }
}
