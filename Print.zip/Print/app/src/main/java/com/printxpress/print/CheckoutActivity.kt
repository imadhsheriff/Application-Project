package com.printxpress.print

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class CheckoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        findViewById<FloatingActionButton>(R.id.backButton).setOnClickListener {
            finish()
        }

        findViewById<Button>(R.id.confirmOrderButton).setOnClickListener {
            Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_LONG).show()
            // In a real app, send data to server
            finish()
        }
    }
}
