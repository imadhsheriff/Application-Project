package com.printxpress.print.models

data class Order(
    val orderId: String,
    val productName: String,
    val date: String,
    val price: Double,
    val status: String // Confirmed, Pending, Cancelled
)
