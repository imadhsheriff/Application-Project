package com.printxpress.print

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText

class EditProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val sharedPref = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val nameInput = findViewById<TextInputEditText>(R.id.nameEditText)
        val emailInput = findViewById<TextInputEditText>(R.id.emailEditText)

        nameInput.setText(sharedPref.getString("name", ""))
        emailInput.setText(sharedPref.getString("email", ""))

        findViewById<FloatingActionButton>(R.id.backButton).setOnClickListener {
            finish()
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val newName = nameInput.text.toString().trim()
            val newEmail = emailInput.text.toString().trim()

            if (newName.isNotEmpty() && newEmail.isNotEmpty()) {
                val editor = sharedPref.edit()
                editor.putString("name", newName)
                editor.putString("email", newEmail)
                editor.apply()

                Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
