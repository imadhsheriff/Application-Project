package com.printxpress.print.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.printxpress.print.ProductDetailActivity
import com.printxpress.print.ProductsActivity
import com.printxpress.print.R
import com.printxpress.print.adapters.ProductCardAdapter
import com.printxpress.print.models.Product

class HomeFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        
        val sharedPref = activity?.getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val name = sharedPref?.getString("name", "User")
        view.findViewById<TextView>(R.id.userNameText).text = name

        view.findViewById<TextView>(R.id.viewAllBtn).setOnClickListener {
            startActivity(Intent(context, ProductsActivity::class.java))
        }

        val popularRv = view.findViewById<RecyclerView>(R.id.popularRecyclerView)
        popularRv.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        val featuredProducts = listOf(
            Product("1", "Business Cards", "Stationery", "Premium 350gsm matte/glossy cards. Pack of 100.", 850.0),
            Product("6", "Ceramic Mugs", "Merchandise", "11oz white ceramic mug with wraparound custom print.", 950.0),
            Product("7", "Cotton T-shirts", "Merchandise", "100% cotton shirts with high-durability DTF print.", 1850.0)
        )

        popularRv.adapter = ProductCardAdapter(featuredProducts) { product ->
            val intent = Intent(context, ProductDetailActivity::class.java).apply {
                putExtra("PRODUCT_NAME", product.name)
                putExtra("PRODUCT_DESC", product.description)
                putExtra("PRODUCT_CAT", product.category)
                putExtra("PRODUCT_PRICE", product.basePrice)
            }
            startActivity(intent)
        }
        
        return view
    }
}
