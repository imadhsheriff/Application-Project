package com.printxpress.print

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nameLayout = findViewById<TextInputLayout>(R.id.nameInputLayout)
        val emailLayout = findViewById<TextInputLayout>(R.id.emailInputLayout)
        val phoneLayout = findViewById<TextInputLayout>(R.id.phoneInputLayout)
        val passwordLayout = findViewById<TextInputLayout>(R.id.passwordInputLayout)

        val nameEditText = findViewById<TextInputEditText>(R.id.nameEditText)
        val emailEditText = findViewById<TextInputEditText>(R.id.emailEditText)
        val phoneEditText = findViewById<TextInputEditText>(R.id.phoneEditText)
        val passwordEditText = findViewById<TextInputEditText>(R.id.passwordEditText)

        findViewById<FloatingActionButton>(R.id.backButton).setOnClickListener {
            finish()
        }

        val registerButton = findViewById<Button>(R.id.registerButton)
        val loginText = findViewById<TextView>(R.id.loginText)

        registerButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val phone = phoneEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            var isValid = true

            if (name.isEmpty()) {
                nameLayout.error = "Name is required"
                isValid = false
            } else {
                nameLayout.error = null
            }

            if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailLayout.error = "Enter a valid email address"
                isValid = false
            } else {
                emailLayout.error = null
            }

            if (phone.length != 10) {
                phoneLayout.error = "Phone number must be 10 characters"
                isValid = false
            } else {
                phoneLayout.error = null
            }

            if (password.length < 8) {
                passwordLayout.error = "Password must be at least 8 characters"
                isValid = false
            } else {
                passwordLayout.error = null
            }

            if (isValid) {
                Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        loginText.setOnClickListener {
            finish()
        }
    }
}
