package com.printxpress.print.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.printxpress.print.EditProfileActivity
import com.printxpress.print.GuidelinesActivity
import com.printxpress.print.LoginActivity
import com.printxpress.print.R

class ProfileFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)
        
        val sharedPref = activity?.getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val name = sharedPref?.getString("name", "User")
        val email = sharedPref?.getString("email", "user@example.com")

        view.findViewById<TextView>(R.id.profileName).text = name
        view.findViewById<TextView>(R.id.profileEmail).text = email

        view.findViewById<Button>(R.id.editProfileBtn).setOnClickListener {
            startActivity(Intent(context, EditProfileActivity::class.java))
        }

        view.findViewById<Button>(R.id.addressBtn).setOnClickListener {
            Toast.makeText(context, "Delivery Addresses feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        view.findViewById<Button>(R.id.designsBtn).setOnClickListener {
            Toast.makeText(context, "Saved Designs feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        view.findViewById<Button>(R.id.guidelinesButton).setOnClickListener {
            startActivity(Intent(context, GuidelinesActivity::class.java))
        }

        view.findViewById<Button>(R.id.logoutButton).setOnClickListener {
            // Clear session on logout
            val editor = sharedPref?.edit()
            editor?.clear()
            editor?.apply()

            val intent = Intent(context, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            activity?.finish()
        }
        
        return view
    }
}
