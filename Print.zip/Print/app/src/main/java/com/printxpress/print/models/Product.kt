package com.printxpress.print.models

data class Product(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val basePrice: Double,
    val imageUrl: String? = null
)
